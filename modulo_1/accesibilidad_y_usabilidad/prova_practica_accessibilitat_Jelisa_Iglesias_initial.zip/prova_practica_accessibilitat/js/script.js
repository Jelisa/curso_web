function comprobarDatos(){
    alert("Su opinión ha sido enviada.")
}